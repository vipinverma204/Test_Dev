(function() {
  commonModule.value('version', '0.1.1');

}).call(this);

//# sourceMappingURL=Config.js.map
